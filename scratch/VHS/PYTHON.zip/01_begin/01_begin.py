print ("Bom dia " * 10)

