
v_int = 10
v_float = 7.2
v_string = "rao"
v_boolean = True

print(v_int)

print(v_float)

print(v_string)

print(v_boolean)
