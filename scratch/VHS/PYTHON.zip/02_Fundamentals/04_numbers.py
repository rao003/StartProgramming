import math


print(10+3)
print(10-3)
print(10/3)
print(10*3)
print(10//3) # dividido inteiro
print(10%3) # modulos , o que sobrou da divisao
print(10**3)  #power


# raiz quadrada

print(math.sqrt(25))

# aumentar e diminuir

x = 5
x = x + 10
# ou x += 10

y = 20
y = y - 10
# ou y -= 10
# 

 