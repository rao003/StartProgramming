courseName = "Python"

message = """
texto maior
com varias linhas
teste
"""

print(message)

"""
comentario de varias linhas
"""

len(courseName)
print(len(courseName))

course = "python BU"

#slice

print(course[0:5])
print(course[-1:-5])
print(course[-5:-1])

# methods , funcoes baseadas em variaveis

print(course.lower())

print(course.replace("BU","bildungs Urlaub"))
print(course.find("BU"))

# string formating

firstName = "ricardo"
lastName = "oliveira"

print(firstName, lastName)
