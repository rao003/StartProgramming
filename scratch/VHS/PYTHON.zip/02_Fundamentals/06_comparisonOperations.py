
print(10>3) # true
print(10<3) # false
print(10==3) # isEqual ? #false
print(10!=3) # notEqual #true

temp = 20
print ( temp < 30 ) 

#logical operations
# and or

# and all the lights needs to be on
# or at least one light on
# XOR either or ... MAX one can be on

adulto = True
geld = False
print("resultado1:",adulto and geld)
print("resultado2:",adulto or geld)
print("resultado3:",adulto and not geld)
print("resultado4:", geld and not adulto)