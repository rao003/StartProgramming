
seunome = input ("Enter your firstName")


print ("bundinha", seunome.title())
print ("to com fome")


