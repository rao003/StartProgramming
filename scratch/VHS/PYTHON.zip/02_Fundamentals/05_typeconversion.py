# conversion type

"""
 int()
 float()
 str()


# exemplo
"""

x = int(input("seu numero"))

x += 10

print("resultado: ", x)

