lista = ["Maria", "Pedro", "Joana"]

searchName = "Maria"

if searchName in lista:
    print(lista.index(searchName))
else:
    print("not found")



