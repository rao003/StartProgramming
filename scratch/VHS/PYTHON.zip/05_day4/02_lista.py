# Index inside LIST

nameList = [["Maria","Silva"],["Jose","Santos"],["Ana","Sobrenome"]]

for x in nameList:
    print(x[0])


print(nameList[0][0])


matrix = [[[[[1,2]]]]]

print(matrix[0][0][0][0][0])  # descasca como uma cebola

