lista = ["Alex","Bia","Catia"]
numeros = [4,2,4,5,6,7,7,7,22,3,33]

numeros.sort() # acending order
numeros.sort(reverse=True)

x = sorted(numeros) # muda a lista original



