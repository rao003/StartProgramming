s = "dfdfdf"
print(s.startswith("d"))