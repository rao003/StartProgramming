hour = 0
minute = 0
second = 0

for hour in range(24):
    for minute in range (60):
        for second in range (60):
            print (hour,":",minute, ":", second)









