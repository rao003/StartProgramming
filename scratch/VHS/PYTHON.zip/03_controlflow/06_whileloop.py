y = 10

while y > 5:
    print("course python", y)
    y -= 1

print("Ende")

"""

temperature = 30
while(True):
    if temparature > 25
    print(temperature)
    temperature -=1
    else:
        break

"""

print("Ende")