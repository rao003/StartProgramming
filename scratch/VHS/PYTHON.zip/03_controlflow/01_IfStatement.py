temperature = 0

if(temperature >=30):
    ar = True
    email = True
    Janela = True
    print("A")
elif(temperature >=20):
    ar = True
    email = True
    Janela = True
    print("B")
elif(temperature >=10):
    ar = True
    email = True
    Janela = True
    print("C")

else:
    print("D")
