
y = "fuck"
while(True):
    if(y != "ende"):
        y = str(input.title("Enter something"))
        print(y)
    else:
        break
    print("you died")


