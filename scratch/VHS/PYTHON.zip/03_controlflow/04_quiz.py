#1
course = "Python Programmierung"

print(course[-2]) # n
print(course[0:6]) # Python
print(course[1:-3]) # ython Programmier


"""
 int()
 float()
 str()

"""

# string



# 
print((course[7:16])+(course[19:21]))

print(course[-14:])

print(course[7:21])