
// Ereignis-Methoden

function button1Click() {

}
function button2Click() {

}
function button3Click() {

}
