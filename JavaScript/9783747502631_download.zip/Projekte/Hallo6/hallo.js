// Ereignis-Methoden

function button1Click() {
  document.getElementById("LBL").innerHTML = "Das freut mich!";
}
function button2Click() {
  document.getElementById("LBL").innerHTML = "Das tut mir leid!";
}
