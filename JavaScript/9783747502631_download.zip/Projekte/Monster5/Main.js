  //Hauptprogramm
  var Frank = new Monster("Frankie", "ungewöhnlich");
  Frank.show();
  var Albert = new GMonster("Bertie", "nachdenklich");
  Albert.show();
  var Sigmund = new SMonster("Sigi", "einfühlsam");
  Sigmund.show();
