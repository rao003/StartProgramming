// Ereignis-Methoden

function button1Click() {
  document.getElementById("LBL").innerHTML = "Das ist ja toll!";
  }
function button2Click() {
  document.getElementById("LBL").innerHTML = "Das freut mich!";
}
function button3Click() {
  document.getElementById("LBL").innerHTML = "Das tut mir leid!";
}
function button4Click() {
  document.getElementById("LBL").innerHTML = "Das ist ja schlimm!";
}
function button5Click() {
  document.getElementById("LBL").innerHTML = "Naja ...";
}
function button6Click() {
  document.getElementById("LBL").innerHTML = "Wenn du meinst ...";
}
