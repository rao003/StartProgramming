// Ereignis-Methoden

function button1Click() {
  document.getElementById("LBL").innerHTML = "Januar";
}
function button2Click() {
  document.getElementById("LBL").innerHTML = "Februar";
}
function button3Click() {
  document.getElementById("LBL").innerHTML = "März";
}
function button4Click() {
  document.getElementById("LBL").innerHTML = "April";
}
function button5Click() {
  document.getElementById("LBL").innerHTML = "Mai";
}
function button6Click() {
  document.getElementById("LBL").innerHTML = "Juni";
}
function button7Click() {
  document.getElementById("LBL").innerHTML = "Juli";
}
function button8Click() {
  document.getElementById("LBL").innerHTML = "August";
}
function button9Click() {
  document.getElementById("LBL").innerHTML = "September";
}
function button10Click() {
  document.getElementById("LBL").innerHTML = "Oktober";
}
function button11Click() {
  document.getElementById("LBL").innerHTML = "November";
}
function button12Click() {
  document.getElementById("LBL").innerHTML = "Dezember";
}
